"""
Frame Dataset - Dataset for Pre-extracted Frames

This module provides a dataset class that works with pre-extracted frames
instead of loading from video files. Useful when frames are already saved.

Author: [Student Name]
Course: [Course Code]
"""

import torch
from torch.utils.data import Dataset
import os
from pathlib import Path
import numpy as np
from PIL import Image
from .utils.transformers import get_train_transform, get_val_transform


class FrameDataset(Dataset):
    """
    Dataset for pre-extracted video frames.
    
    Expected directory structure:
    data/
        video1/
            frame_0001.jpg
            frame_0002.jpg
            ...
            label.txt  (contains: 0 or 1)
        video2/
            frame_0001.jpg
            ...
    
    Args:
        root_dir (str): Root directory containing video frame folders
        num_frames (int): Number of frames to sample
        frame_size (tuple): Target frame size
        transform: Transform to apply
        split (str): 'train', 'val', or 'test'
    """
    
    def __init__(self, root_dir, num_frames=16, frame_size=(224, 224),
                 transform=None, split='train'):
        self.root_dir = Path(root_dir)
        self.num_frames = num_frames
        self.frame_size = frame_size
        self.split = split
        
        # Set up transforms
        if transform is None:
            if split == 'train':
                self.transform = get_train_transform(frame_size, num_frames)
            else:
                self.transform = get_val_transform(frame_size, num_frames)
        else:
            self.transform = transform
        
        # Load video folders and labels
        self.video_folders = []
        self.labels = []
        
        self._load_dataset()
        
        print(f"\n{split.upper()} Frame Dataset loaded:")
        print(f"  Total videos: {len(self.video_folders)}")
        print(f"  Frames per video: {num_frames}")
    
    def _load_dataset(self):
        """
        Load all video folders and their labels.
        """
        # Get all video directories
        video_dirs = sorted([d for d in self.root_dir.iterdir() if d.is_dir()])
        
        for video_dir in video_dirs:
            # Check if label file exists
            label_file = video_dir / 'label.txt'
            
            if not label_file.exists():
                print(f"Warning: No label file found for {video_dir.name}, skipping")
                continue
            
            # Read label
            with open(label_file, 'r') as f:
                label = int(f.read().strip())
            
            # Check if frames exist
            frame_files = sorted(list(video_dir.glob('*.jpg')) + 
                               list(video_dir.glob('*.png')))
            
            if len(frame_files) == 0:
                print(f"Warning: No frames found in {video_dir.name}, skipping")
                continue
            
            self.video_folders.append(video_dir)
            self.labels.append(label)
    
    def __len__(self):
        return len(self.video_folders)
    
    def __getitem__(self, idx):
        """
        Load frames from a video folder.
        
        Args:
            idx (int): Index of the video
        
        Returns:
            tuple: (video_tensor, label)
        """
        video_dir = self.video_folders[idx]
        label = self.labels[idx]
        
        # Get all frame files
        frame_files = sorted(list(video_dir.glob('*.jpg')) + 
                           list(video_dir.glob('*.png')))
        
        total_frames = len(frame_files)
        
        # Sample frame indices uniformly
        if total_frames < self.num_frames:
            # If too few frames, repeat
            indices = np.linspace(0, total_frames - 1, self.num_frames, dtype=int)
        else:
            # Uniform sampling
            indices = np.linspace(0, total_frames - 1, self.num_frames, dtype=int)
        
        # Load frames
        frames = []
        for idx in indices:
            frame_path = frame_files[idx]
            
            # Load image
            try:
                frame = Image.open(frame_path).convert('RGB')
                frame = np.array(frame)
                frames.append(frame)
            except Exception as e:
                print(f"Error loading {frame_path}: {e}")
                # Use black frame as fallback
                frames.append(np.zeros((self.frame_size[0], self.frame_size[1], 3), 
                                      dtype=np.uint8))
        
        # Convert to numpy array
        frames = np.array(frames)
        
        # Normalize to [0, 1]
        frames = frames.astype(np.float32) / 255.0
        
        # Apply transforms
        if self.transform:
            video_tensor = self.transform(frames)
        else:
            frames = np.transpose(frames, (3, 0, 1, 2))
            video_tensor = torch.from_numpy(frames)
        
        return video_tensor, label


def extract_frames_from_video(video_path, output_dir, num_frames=None):
    """
    Extract frames from a video and save them to a directory.
    
    This is a utility function to pre-process videos into frames.
    
    Args:
        video_path (str): Path to video file
        output_dir (str): Directory to save frames
        num_frames (int): Number of frames to extract (None = all)
    
    Example:
        >>> extract_frames_from_video('video.mp4', 'frames/video1')
    """
    import cv2
    
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Open video
    cap = cv2.VideoCapture(str(video_path))
    
    if not cap.isOpened():
        print(f"Error: Cannot open {video_path}")
        return
    
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    
    # Determine which frames to extract
    if num_frames is None or num_frames >= total_frames:
        frame_indices = list(range(total_frames))
    else:
        frame_indices = np.linspace(0, total_frames - 1, num_frames, dtype=int)
    
    print(f"Extracting {len(frame_indices)} frames from {video_path}")
    
    # Extract frames
    for i, frame_idx in enumerate(frame_indices):
        cap.set(cv2.CAP_PROP_POS_FRAMES, frame_idx)
        ret, frame = cap.read()
        
        if not ret:
            print(f"Warning: Could not read frame {frame_idx}")
            continue
        
        # Save frame
        frame_path = output_dir / f"frame_{i:04d}.jpg"
        cv2.imwrite(str(frame_path), frame)
        
        if (i + 1) % 10 == 0:
            print(f"  Extracted {i + 1}/{len(frame_indices)} frames")
    
    cap.release()
    print(f"✓ Frames saved to {output_dir}")


if __name__ == "__main__":
    print("Frame Dataset Module")
    print("=" * 60)
    print("\nThis module provides:")
    print("  - FrameDataset: Dataset for pre-extracted frames")
    print("  - extract_frames_from_video(): Extract frames from video")
    
    print("\nExample usage:")
    print(">>> extract_frames_from_video('video.mp4', 'frames/video1')")
    print(">>> dataset = FrameDataset('data/train_frames')")
