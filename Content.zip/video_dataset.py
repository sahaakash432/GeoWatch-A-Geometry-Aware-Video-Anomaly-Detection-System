"""
Video Dataset - PyTorch Dataset for Video Classification

This module provides a custom Dataset class for loading videos
and their labels for training/testing.

Author: [Student Name]
Course: [Course Code]
"""

import torch
from torch.utils.data import Dataset
import os
from pathlib import Path
import numpy as np
from .utils.load import load_video_frames
from .utils.transformers import get_train_transform, get_val_transform


class VideoDataset(Dataset):
    """
    Custom Dataset for video classification.
    
    This dataset loads videos from a directory structure like:
    data/
        class_0/
            video1.mp4
            video2.mp4
        class_1/
            video3.mp4
            video4.mp4
    
    Args:
        root_dir (str): Root directory containing class folders
        num_frames (int): Number of frames to sample from each video
        frame_size (tuple): Target size for frames (height, width)
        transform: Transform to apply to videos
        split (str): 'train', 'val', or 'test'
    
    Example:
        >>> dataset = VideoDataset('data/train', num_frames=16)
        >>> video, label = dataset[0]
        >>> print(video.shape, label)
    """
    
    def __init__(self, root_dir, num_frames=16, frame_size=(224, 224), 
                 transform=None, split='train'):
        self.root_dir = Path(root_dir)
        self.num_frames = num_frames
        self.frame_size = frame_size
        self.split = split
        
        # Set up transforms
        if transform is None:
            if split == 'train':
                self.transform = get_train_transform(frame_size, num_frames)
            else:
                self.transform = get_val_transform(frame_size, num_frames)
        else:
            self.transform = transform
        
        # Load video paths and labels
        self.video_paths = []
        self.labels = []
        self.class_names = []
        
        self._load_dataset()
        
        print(f"\n{split.upper()} Dataset loaded:")
        print(f"  Total videos: {len(self.video_paths)}")
        print(f"  Classes: {self.class_names}")
        print(f"  Class distribution: {self._get_class_distribution()}")
    
    def _load_dataset(self):
        """
        Load all video paths and their corresponding labels.
        """
        # Get all class directories
        class_dirs = sorted([d for d in self.root_dir.iterdir() if d.is_dir()])
        
        if len(class_dirs) == 0:
            raise ValueError(f"No class directories found in {self.root_dir}")
        
        # Map class names to indices
        self.class_names = [d.name for d in class_dirs]
        class_to_idx = {name: idx for idx, name in enumerate(self.class_names)}
        
        # Load video paths from each class
        for class_dir in class_dirs:
            class_name = class_dir.name
            class_idx = class_to_idx[class_name]
            
            # Find all video files in this class directory
            video_extensions = ['.mp4', '.avi', '.mov', '.mkv']
            video_files = []
            
            for ext in video_extensions:
                video_files.extend(class_dir.glob(f'*{ext}'))
            
            # Add to dataset
            for video_path in video_files:
                self.video_paths.append(str(video_path))
                self.labels.append(class_idx)
    
    def _get_class_distribution(self):
        """
        Get the distribution of classes in the dataset.
        
        Returns:
            dict: Class name to count mapping
        """
        from collections import Counter
        label_counts = Counter(self.labels)
        return {self.class_names[idx]: count 
                for idx, count in label_counts.items()}
    
    def __len__(self):
        """
        Return the total number of videos in the dataset.
        """
        return len(self.video_paths)
    
    def __getitem__(self, idx):
        """
        Load and return a video and its label.
        
        Args:
            idx (int): Index of the video to load
        
        Returns:
            tuple: (video_tensor, label)
                video_tensor: PyTorch tensor of shape (C, T, H, W)
                label: Integer class label
        """
        # Get video path and label
        video_path = self.video_paths[idx]
        label = self.labels[idx]
        
        # Load video frames
        frames = load_video_frames(
            video_path,
            num_frames=self.num_frames,
            frame_size=self.frame_size
        )
        
        if frames is None:
            # If video loading fails, return a zero tensor
            print(f"Warning: Failed to load {video_path}, returning zeros")
            video_tensor = torch.zeros(3, self.num_frames, 
                                       self.frame_size[0], self.frame_size[1])
        else:
            # Normalize frames to [0, 1]
            frames = frames.astype(np.float32) / 255.0
            
            # Apply transformations
            if self.transform:
                video_tensor = self.transform(frames)
            else:
                # If no transform, just convert to tensor
                frames = np.transpose(frames, (3, 0, 1, 2))
                video_tensor = torch.from_numpy(frames)
        
        return video_tensor, label


class SimpleVideoDataset(Dataset):
    """
    Simplified video dataset for quick testing.
    
    Takes a list of video paths and labels directly.
    
    Args:
        video_paths (list): List of paths to video files
        labels (list): List of corresponding labels
        num_frames (int): Number of frames to sample
        frame_size (tuple): Target frame size
        transform: Transform to apply
    
    Example:
        >>> paths = ['video1.mp4', 'video2.mp4']
        >>> labels = [0, 1]
        >>> dataset = SimpleVideoDataset(paths, labels)
    """
    
    def __init__(self, video_paths, labels, num_frames=16, 
                 frame_size=(224, 224), transform=None):
        self.video_paths = video_paths
        self.labels = labels
        self.num_frames = num_frames
        self.frame_size = frame_size
        self.transform = transform if transform else get_val_transform(frame_size, num_frames)
        
        assert len(video_paths) == len(labels), \
            "Number of videos and labels must match"
    
    def __len__(self):
        return len(self.video_paths)
    
    def __getitem__(self, idx):
        video_path = self.video_paths[idx]
        label = self.labels[idx]
        
        # Load frames
        frames = load_video_frames(
            video_path,
            num_frames=self.num_frames,
            frame_size=self.frame_size
        )
        
        if frames is None:
            video_tensor = torch.zeros(3, self.num_frames, 
                                       self.frame_size[0], self.frame_size[1])
        else:
            frames = frames.astype(np.float32) / 255.0
            video_tensor = self.transform(frames)
        
        return video_tensor, label


def create_dataloaders(train_dir, val_dir, test_dir=None, 
                      batch_size=8, num_frames=16, 
                      frame_size=(224, 224), num_workers=2):
    """
    Create train, validation, and test dataloaders.
    
    Args:
        train_dir (str): Path to training data directory
        val_dir (str): Path to validation data directory
        test_dir (str): Path to test data directory (optional)
        batch_size (int): Batch size for dataloaders
        num_frames (int): Number of frames per video
        frame_size (tuple): Target frame size
        num_workers (int): Number of worker processes for data loading
    
    Returns:
        tuple: (train_loader, val_loader, test_loader)
               test_loader is None if test_dir not provided
    
    Example:
        >>> train_loader, val_loader, test_loader = create_dataloaders(
        ...     'data/train', 'data/val', 'data/test', batch_size=8
        ... )
    """
    from torch.utils.data import DataLoader
    
    # Create datasets
    train_dataset = VideoDataset(
        train_dir,
        num_frames=num_frames,
        frame_size=frame_size,
        split='train'
    )
    
    val_dataset = VideoDataset(
        val_dir,
        num_frames=num_frames,
        frame_size=frame_size,
        split='val'
    )
    
    # Create dataloaders
    train_loader = DataLoader(
        train_dataset,
        batch_size=batch_size,
        shuffle=True,
        num_workers=num_workers,
        pin_memory=True
    )
    
    val_loader = DataLoader(
        val_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        pin_memory=True
    )
    
    # Optional test set
    test_loader = None
    if test_dir:
        test_dataset = VideoDataset(
            test_dir,
            num_frames=num_frames,
            frame_size=frame_size,
            split='test'
        )
        
        test_loader = DataLoader(
            test_dataset,
            batch_size=batch_size,
            shuffle=False,
            num_workers=num_workers,
            pin_memory=True
        )
    
    return train_loader, val_loader, test_loader


if __name__ == "__main__":
    print("Video Dataset Module")
    print("=" * 60)
    print("\nAvailable classes:")
    print("  - VideoDataset: Main dataset class")
    print("  - SimpleVideoDataset: Simplified dataset")
    print("  - create_dataloaders(): Helper to create all dataloaders")
    
    print("\nExample usage:")
    print(">>> dataset = VideoDataset('data/train', num_frames=16)")
    print(">>> video, label = dataset[0]")
    print(">>> print(video.shape, label)")
