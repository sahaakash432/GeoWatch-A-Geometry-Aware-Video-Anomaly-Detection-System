"""
Content Package - Spatiotemporal Anomaly Detection
Student Implementation

This package contains all the modules needed for video-based anomaly detection:
- models: Neural network architectures
- trainers: Training and evaluation functions
- utils: Helper functions for data loading and transformations
- datasets: Custom dataset classes for video data

Author: [Student Name]
Date: February 2026
"""

# Package version
__version__ = "1.0.0"

# Import key components for easier access
from .models.ucf_model import I3D_Classifier
from .trainers.ucf_trainer import train_model, evaluate_model
from .utils.load import load_video_frames
from .utils.transformers import VideoTransform

# Make these available at package level
__all__ = [
    'I3D_Classifier',
    'train_model',
    'evaluate_model',
    'load_video_frames',
    'VideoTransform'
]
