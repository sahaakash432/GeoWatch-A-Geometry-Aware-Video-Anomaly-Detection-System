"""
Encoded Video Dataset - Dataset for Pre-processed Video Tensors

This module provides a dataset class for videos that have been pre-processed
and saved as PyTorch tensors. This speeds up training by avoiding repeated
video decoding.

Author: [Student Name]
Course: [Course Code]
"""

import torch
from torch.utils.data import Dataset
import os
from pathlib import Path
import numpy as np


class EncodedVideoDataset(Dataset):
    """
    Dataset for pre-encoded video tensors.
    
    This is useful when you want to pre-process all videos once
    and save them as tensors to speed up training.
    
    Expected directory structure:
    data/
        video1.pt  (saved tensor)
        video2.pt
        ...
        labels.txt  (one label per line)
    
    Args:
        root_dir (str): Directory containing .pt files
        labels_file (str): Path to labels file (or list of labels)
        transform: Additional transforms to apply
    
    Example:
        >>> dataset = EncodedVideoDataset('data/encoded', 'data/labels.txt')
        >>> video, label = dataset[0]
    """
    
    def __init__(self, root_dir, labels_file=None, transform=None):
        self.root_dir = Path(root_dir)
        self.transform = transform
        
        # Load tensor files
        self.tensor_files = sorted(list(self.root_dir.glob('*.pt')))
        
        # Load labels
        if labels_file is None:
            # Try to find labels.txt in root_dir
            labels_file = self.root_dir / 'labels.txt'
        
        if isinstance(labels_file, (str, Path)) and Path(labels_file).exists():
            with open(labels_file, 'r') as f:
                self.labels = [int(line.strip()) for line in f]
        elif isinstance(labels_file, list):
            self.labels = labels_file
        else:
            # No labels provided, use dummy labels
            print("Warning: No labels provided, using zeros")
            self.labels = [0] * len(self.tensor_files)
        
        assert len(self.tensor_files) == len(self.labels), \
            f"Number of videos ({len(self.tensor_files)}) must match " \
            f"number of labels ({len(self.labels)})"
        
        print(f"\nEncoded Video Dataset loaded:")
        print(f"  Total videos: {len(self.tensor_files)}")
        print(f"  Directory: {self.root_dir}")
    
    def __len__(self):
        return len(self.tensor_files)
    
    def __getitem__(self, idx):
        """
        Load a pre-encoded video tensor.
        
        Args:
            idx (int): Index of the video
        
        Returns:
            tuple: (video_tensor, label)
        """
        # Load tensor file
        tensor_path = self.tensor_files[idx]
        
        try:
            video_tensor = torch.load(tensor_path)
        except Exception as e:
            print(f"Error loading {tensor_path}: {e}")
            # Return zero tensor as fallback
            video_tensor = torch.zeros(3, 16, 224, 224)
        
        label = self.labels[idx]
        
        # Apply additional transforms if provided
        if self.transform:
            video_tensor = self.transform(video_tensor)
        
        return video_tensor, label


def encode_video_dataset(input_dir, output_dir, num_frames=16, 
                        frame_size=(224, 224), transform=None):
    """
    Pre-process all videos in a directory and save as tensors.
    
    This function:
    1. Loads all videos from input_dir
    2. Processes them (sampling, resizing, normalizing)
    3. Saves as .pt files in output_dir
    
    Args:
        input_dir (str): Directory containing video files
        output_dir (str): Directory to save encoded tensors
        num_frames (int): Number of frames per video
        frame_size (tuple): Target frame size
        transform: Transform to apply during encoding
    
    Example:
        >>> encode_video_dataset('data/videos', 'data/encoded')
    """
    from .utils.load import load_video_as_tensor
    from .utils.transformers import get_val_transform
    
    input_dir = Path(input_dir)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # Get transform if not provided
    if transform is None:
        transform = get_val_transform(frame_size, num_frames)
    
    # Find all video files
    video_extensions = ['.mp4', '.avi', '.mov', '.mkv']
    video_files = []
    for ext in video_extensions:
        video_files.extend(input_dir.glob(f'*{ext}'))
    
    video_files = sorted(video_files)
    
    print(f"Encoding {len(video_files)} videos...")
    print(f"Output directory: {output_dir}")
    print("-" * 60)
    
    # Process each video
    for i, video_path in enumerate(video_files):
        print(f"Processing {i+1}/{len(video_files)}: {video_path.name}")
        
        try:
            # Load video as tensor
            video_tensor = load_video_as_tensor(
                str(video_path),
                num_frames=num_frames,
                frame_size=frame_size
            )
            
            if video_tensor is None:
                print(f"  ⚠ Failed to load, skipping")
                continue
            
            # Apply transform if needed
            if transform and not isinstance(video_tensor, torch.Tensor):
                frames = video_tensor.numpy()
                frames = np.transpose(frames, (1, 2, 3, 0))  # C,T,H,W -> T,H,W,C
                video_tensor = transform(frames)
            
            # Save tensor
            output_path = output_dir / f"{video_path.stem}.pt"
            torch.save(video_tensor, output_path)
            
            print(f"  ✓ Saved to {output_path.name}")
            
        except Exception as e:
            print(f"  ⚠ Error: {e}")
            continue
    
    print("-" * 60)
    print(f"✓ Encoding complete! {len(list(output_dir.glob('*.pt')))} tensors saved")


def create_labels_file(video_paths, labels, output_file):
    """
    Create a labels file for encoded videos.
    
    Args:
        video_paths (list): List of video paths (in order)
        labels (list): Corresponding labels
        output_file (str): Path to save labels.txt
    
    Example:
        >>> paths = ['video1.mp4', 'video2.mp4']
        >>> labels = [0, 1]
        >>> create_labels_file(paths, labels, 'labels.txt')
    """
    assert len(video_paths) == len(labels), \
        "Number of videos must match number of labels"
    
    with open(output_file, 'w') as f:
        for label in labels:
            f.write(f"{label}\n")
    
    print(f"✓ Labels file created: {output_file}")


if __name__ == "__main__":
    print("Encoded Video Dataset Module")
    print("=" * 60)
    print("\nThis module provides:")
    print("  - EncodedVideoDataset: Dataset for pre-encoded tensors")
    print("  - encode_video_dataset(): Pre-process and save videos")
    print("  - create_labels_file(): Create labels file")
    
    print("\nWorkflow:")
    print("1. Pre-process videos once:")
    print("   >>> encode_video_dataset('videos/', 'encoded/')")
    print("\n2. Create labels file:")
    print("   >>> create_labels_file(paths, labels, 'encoded/labels.txt')")
    print("\n3. Use in training:")
    print("   >>> dataset = EncodedVideoDataset('encoded/', 'encoded/labels.txt')")
    
    print("\nBenefit: Much faster training since videos are decoded only once!")
