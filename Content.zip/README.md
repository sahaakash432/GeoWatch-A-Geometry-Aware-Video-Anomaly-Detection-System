# Content Package - Spatiotemporal Anomaly Detection

**Student Project for Geometrically Constrained Surveillance System**

This package contains all the code needed for training and evaluating an I3D-based video anomaly detection system.

## 📁 Package Structure

```
Content/
├── __init__.py                      # Package initialization
├── video_dataset.py                 # Main video dataset class
├── frame_dataset.py                 # Dataset for pre-extracted frames
├── encoded_video_dataset.py         # Dataset for pre-encoded tensors
├── models/
│   ├── __init__.py
│   └── ucf_model.py                # I3D model implementation
├── trainers/
│   ├── __init__.py
│   └── ucf_trainer.py              # Training and evaluation functions
└── utils/
    ├── __init__.py
    ├── load.py                      # Video loading utilities
    └── transformers.py              # Data augmentation/preprocessing
```

## 🚀 Quick Start

### 1. Installation

Upload `Content.zip` to your Google Colab and extract:

```python
!unzip -q Content.zip -d /content/
import sys
sys.path.insert(0, '/content/dataset')
```

### 2. Import Components

```python
from Content.models import I3D_Classifier, create_i3d_model
from Content.trainers import train_model, evaluate_model
from Content.utils import load_video_frames, get_train_transform
from Content.video_dataset import VideoDataset, create_dataloaders
```

### 3. Create Model

```python
# Create model with different strategies
model = create_i3d_model(num_classes=2, strategy='partial')

# Or customize
model = I3D_Classifier(num_classes=2, pretrained=True)
model = model.to(device)
```

### 4. Prepare Data

```python
# Option 1: From directory structure
train_loader, val_loader, test_loader = create_dataloaders(
    train_dir='data/train',
    val_dir='data/val',
    test_dir='data/test',
    batch_size=8,
    num_frames=16
)

# Option 2: Custom dataset
from Content.video_dataset import VideoDataset
dataset = VideoDataset(
    root_dir='data/train',
    num_frames=16,
    frame_size=(224, 224),
    split='train'
)
```

### 5. Train Model

```python
import torch.optim as optim
import torch.nn as nn

# Setup training
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=1e-4)
scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, patience=2)

# Train
history = train_model(
    model=model,
    train_loader=train_loader,
    val_loader=val_loader,
    criterion=criterion,
    optimizer=optimizer,
    num_epochs=10,
    device=device,
    scheduler=scheduler
)
```

### 6. Evaluate Model

```python
results = evaluate_model(
    model=model,
    test_loader=test_loader,
    device=device,
    class_names=['Normal', 'Anomaly']
)

print(f"Test Accuracy: {results['accuracy']:.2f}%")
print(f"F1 Score: {results['f1_score']:.2f}%")
```

## 📚 Module Documentation

### Models Module (`models/`)

**I3D_Classifier**: Main model class
- Supports different fine-tuning strategies
- Methods: `forward()`, `unfreeze_all()`, `unfreeze_last_block()`

**create_i3d_model()**: Factory function
- Strategies: `'freeze'`, `'partial'`, `'full'`
- Returns configured model instance

### Trainers Module (`trainers/`)

**train_model()**: Complete training loop
- Automatic checkpointing
- Learning rate scheduling support
- Progress tracking with tqdm

**evaluate_model()**: Test evaluation
- Computes accuracy, precision, recall, F1
- Returns confusion matrix and predictions

### Utils Module (`utils/`)

**load.py**: Video loading functions
- `load_video_frames()`: Load and sample frames
- `load_video_as_tensor()`: Direct tensor loading
- `get_video_info()`: Video metadata

**transformers.py**: Data preprocessing
- `get_train_transform()`: Training augmentation
- `get_val_transform()`: Validation preprocessing
- Individual transforms: Resize, Normalize, ColorJitter, etc.

### Dataset Classes

**VideoDataset**: Load videos from directory structure
- Expects: `data/class_0/video1.mp4`, `data/class_1/video2.mp4`
- Handles sampling, resizing, augmentation

**FrameDataset**: Load pre-extracted frames
- Useful when frames are already saved
- Faster than loading from video

**EncodedVideoDataset**: Load pre-processed tensors
- Pre-encode videos once, train faster
- Use `encode_video_dataset()` to prepare data

## 🎯 Fine-tuning Strategies

### 1. Feature Extraction (Freeze)
```python
model = create_i3d_model(strategy='freeze')
```
- Freezes all layers except final classifier
- Fastest training, lowest memory
- Good for small datasets

### 2. Partial Fine-tuning (Recommended)
```python
model = create_i3d_model(strategy='partial')
```
- Unfreezes last block of I3D
- Balanced performance and efficiency
- Best for most scenarios

### 3. Full Fine-tuning
```python
model = create_i3d_model(strategy='full')
```
- All layers trainable
- Highest potential accuracy
- Requires more data and compute

## 🔧 Advanced Usage

### Custom Video Loading

```python
from Content.utils import load_video_frames

frames = load_video_frames(
    'video.mp4',
    num_frames=16,
    frame_size=(224, 224)
)
```

### Custom Transforms

```python
from Content.utils.transformers import VideoTransform, Resize, Normalize, ColorJitter

transform = VideoTransform([
    Resize((224, 224)),
    ColorJitter(brightness=0.3),
    Normalize(mean=[0.45, 0.45, 0.45], std=[0.225, 0.225, 0.225])
])
```

### Pre-encoding Videos

```python
from Content.encoded_video_dataset import encode_video_dataset

# Encode all videos once
encode_video_dataset(
    input_dir='data/videos',
    output_dir='data/encoded',
    num_frames=16,
    frame_size=(224, 224)
)

# Then use encoded dataset for faster training
dataset = EncodedVideoDataset('data/encoded', 'data/labels.txt')
```

## 📊 Expected Input Format

### Video Tensor Shape
- Input: `(Batch, Channels, Time, Height, Width)`
- Example: `(8, 3, 16, 224, 224)` for batch of 8 videos
- Channels: RGB (3)
- Time: 16 frames (I3D default)
- Spatial: 224x224 pixels

### Directory Structure for VideoDataset
```
data/
├── train/
│   ├── normal/
│   │   ├── video1.mp4
│   │   └── video2.mp4
│   └── anomaly/
│       ├── video3.mp4
│       └── video4.mp4
├── val/
│   ├── normal/
│   └── anomaly/
└── test/
    ├── normal/
    └── anomaly/
```

## ⚠️ Common Issues and Solutions

### Issue: "Cannot open video file"
- Check video codec compatibility
- Try converting to H.264 codec: `ffmpeg -i input.mp4 -c:v libx264 output.mp4`

### Issue: "Out of memory"
- Reduce batch_size
- Use gradient accumulation
- Try `strategy='freeze'` for less memory usage

### Issue: "Video loading is slow"
- Pre-encode videos using `encode_video_dataset()`
- Reduce `num_workers` if causing issues
- Use SSD for faster I/O

## 📝 Notes for Professor

This code demonstrates understanding of:
- Transfer learning and fine-tuning strategies
- PyTorch dataset and dataloader patterns
- Video processing and temporal modeling
- Proper code organization and documentation
- Handling edge cases (missing files, corrupted videos)

All functions include:
- Detailed docstrings
- Type hints where appropriate
- Error handling
- Progress feedback
- Clear comments explaining the "why" not just the "what"

## 🤝 Credits

- I3D model: Carreira & Zisserman (2017)
- PyTorchVideo library: Meta AI
- Student implementation: [Your Name]
- Course: [Course Code]

## 📄 License

This is student coursework. All rights reserved.
